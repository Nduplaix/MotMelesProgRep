package jeu;

public class MessagesEchanges {
	static final public String CONNEXION_ACCEPTEE="Soyez le bienvenu !";
	static final public String PSEUDO_UTILISE="Pseudonyme déjà utilisé !";
	static final public String COUP_GAGNANT="Votre coup est gagnant !";
	static final public String COUP_PERDANT="Votre coup est perdant !";
	static final public String TERMINEE="La partie est terminée !";
	static final public String RECOMMENCE="Une nouvelle partie ! Cool !";
	static final public String FIN_JEU="Fin du Jeu ! A Bientôt !";
	static final public String FIN_CLASSEMENT="Fin de l'affichage du classement de la partie !";
	static final public String DEBLOQUE_GRILLE="Deblocage de la fenêtre !";
	//COUP 0 17 0 21
}
